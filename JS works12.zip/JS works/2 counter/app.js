// ======================option l =================
// let num = 0;
// let count = document.getElementById('value');
// const decrease = document.querySelector(".decrease");
// decrease.addEventListener("click", function(){
// num--;
// count.innerHTML = num;
// });

// const reset = document.querySelector(".reset");
// reset.addEventListener("click", 
// function(){ 
//       num=0;
//       count.innerHTML = num});


//  const increase = document.querySelector(".increase");
// increase.addEventListener("click", 
// function(){ 
//       num++;
//       count.innerHTML = num});

// ======================option 2 =================

let num =0;
const buttons = document.querySelectorAll("button");
const value = document.getElementById("value");
buttons.forEach(btn => {
      btn.addEventListener("click", function(e) {
            const clicked = e.currentTarget.classList;
          if (clicked.contains ("decrease")){
                num--;
          }
 else if (clicked.contains ("reset")){
      num =0;
}
else {num++};
  value.innerHTML= num;

  if (num < 0) {  value.style.color = "red"};
  if (num>0){value.style.color = "green"};
  if (num===0) {value.style.color ="#222"}
      })
});


